from flask import Flask, render_template, request, jsonify
from flask_paginate import Pagination, get_page_parameter
from UserScraper import UserScraper
from  DataHandler import DataHandler

app = Flask(__name__)
similar_films = []
filtered_films = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    global similar_films
    similar_films = []
   
    usernames = request.form.getlist('usernames[]')
    scraper = UserScraper()
    data_handler = DataHandler()
    data_handler.insert_genre_db()
    user_urls = {}

    for username in usernames:
        watchlist_films = scraper.scrape_user(username, "watchlist")
        if watchlist_films == False:
            return jsonify({'error': 'One or more usernames don\'t exist. Please try again.'}), 400
        user_urls[username] = set(scraper.get_uris(watchlist_films))

    common_urls = set.intersection(*user_urls.values())
    data_handler.process_data(common_urls,'w')

    similar_films = data_handler.process_providers(data_handler.watchlist)

    return jsonify(True)
    


@app.route('/films')
def films():
    global similar_films
    global filtered_films
    filtered = False
    filter_options = request.args

    for i in filter_options:
        if i.startswith("gen_") or i.startswith("provider_") or i.startswith("run_"):
            filtered_films = get_filtered_films(filter_options)
            filtered = True
            break
        if i.startswith("blank"):
            filtered_films = similar_films
            filtered = False
            break

    if filtered and not filtered_films:
        filtered_films = []

    if not similar_films:
        return render_template('error.html')
            
    sorting_option = request.args.get('sorting_option', default='year_latest', type=str)
    sorted_films = get_sorted_films(filtered_films,sorting_option)

    page = request.args.get(get_page_parameter(), type=int, default=1)
    per_page = 20  # Number of films per page
    offset = (page - 1) * per_page

    paginated_films = sorted_films[offset: offset + per_page]

    pagination = Pagination(page=page, total=len(filtered_films if filtered else sorted_films), per_page=per_page, css_framework='bootstrap')

    return render_template('films.html',pagination=pagination,data=similar_films,isFiltered=filtered,filtered_films=paginated_films)

def get_sorted_films(f, sorting_option):
   
    if sorting_option == 'year_latest':
        sorted_films = sorted(f, key=lambda film: int(film.year_released) if film.year_released else 0, reverse=True)
    elif sorting_option == 'year_earliest':
        sorted_films = sorted(f, key=lambda film: int(film.year_released)if film.year_released else 0)
    elif sorting_option == 'rating_highest':
        sorted_films = sorted(f, key=lambda film: int(film.details.rating) if film.details.rating else 0, reverse=True)
    elif sorting_option == 'rating_lowest':
        sorted_films = sorted(f, key=lambda film: int(film.details.rating) if film.details.rating else 0)
    elif sorting_option == 'longest':
        sorted_films = sorted(f, key=lambda film: film.details.runtime, reverse=True)
    elif sorting_option == 'shortest':
        sorted_films = sorted(f, key=lambda film: film.details.runtime)
    else:
        # Default sorting option
        sorted_films = f

    return sorted_films

    


def get_filtered_films(filter_options):
    global similar_films
    filtered_films = []
    for option in filter_options:
        if option.startswith("provider_"):
            provider_id = int(option.split("_")[1])
            for film in similar_films:
                if 'CA' in film.details.providers:
                    if 'free' in film.details.providers['CA']:
                        for provider in film.details.providers['CA']['free']:
                            if provider['provider_id'] == provider_id and film not in filtered_films:
                                filtered_films.append(film)
                    if 'flatrate' in film.details.providers['CA']:
                        for provider in film.details.providers['CA']['flatrate']:
                            if provider['provider_id'] == provider_id and film not in filtered_films:
                                filtered_films.append(film)
        if option.startswith("gen"):
            if filtered_films:
                data = filtered_films
            else:
                data = similar_films

            filtered_films = get_filtered_genre(data,option.split("_")[1])

        if option.startswith("run"):
            if filtered_films:
                data = filtered_films
            else:
                data = similar_films

            filtered_films = get_filtered_run(data,option.split("_")[1])

    return filtered_films

def get_filtered_run(data,run):
    if run == "90":
        run = 90
        filtered_films = [film for film in data if run >= film.details.runtime]
    elif run == "120":
        run = 120
        filtered_films = [film for film in data if run >= film.details.runtime]
    elif run == "120+":
        run = 120
        filtered_films = [film for film in data if run <= film.details.runtime]

    return filtered_films

def get_filtered_genre(data,genre):
    filtered_films = [film for film in data if genre in film.details.genres]
    return filtered_films

if __name__ == '__main__':
    app.run(debug=True)
